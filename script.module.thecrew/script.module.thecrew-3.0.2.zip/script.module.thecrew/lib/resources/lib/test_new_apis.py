# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on
 *
 *
 * @file test_new_apis.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2023-2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 * Test file for new API classes (TMDbAPI, TVDbAPI, FanartAPI)
 *
 * NOTE: This test requires a running Kodi instance and must be executed
 * from within Kodi's Python environment to access Kodi modules.
 *
 * Run from Kodi Python console or via DevTools -> Test API Classes
 *
 ********************************************************cm*
'''

import sys
import os

print("="*80)
print("API Test Suite - Loading modules...")
print("="*80)

try:
    # These imports require Kodi environment
    from apis.tmdb_api import TMDbAPI
    from apis.tvdb_api import TVDbAPI
    from apis.fanart_api import FanartAPI
    print("(OK) API modules imported successfully")
except ImportError as e:
    print(f"\n(X) IMPORT ERROR: {e}")
    print("\nThis test requires Kodi's Python environment.")
    print("Please run this test from within Kodi using:")
    print("  1. DevTools -> Python Console")
    print("  2. Or execute via Kodi addon mechanism")
    print("\nStandalone Python cannot access Kodi modules (xbmc, xbmcvfs, etc.)")
    sys.exit(1)


def test_tmdb_api():
    """Test TMDb API with simple calls"""
    print("\n" + "="*80)
    print("TESTING TMDb API")
    print("="*80)

    api = TMDbAPI()
    print(f"(OK) TMDbAPI initialized")
    print(f"  - API Key: {api.api_key[:8]}...")
    print(f"  - Language: {api.language}")

    # Test 1: Get popular movies
    print("\n[Test 1] Getting popular movies...")
    try:
        movies = api.get_popular_movies()
        if movies and 'results' in movies:
            print(f"(OK) Success! Found {len(movies['results'])} popular movies")
            if movies['results']:
                first = movies['results'][0]
                print(f"  - First movie: {first.get('title', 'N/A')} ({first.get('release_date', 'N/A')[:4]})")
        else:
            print("(X) Failed - No results returned")
    except Exception as e:
        print(f"(X) Error: {e}")

    # Test 2: Get specific movie (Fight Club - TMDb ID: 550)
    print("\n[Test 2] Getting movie details (Fight Club - ID: 550)...")
    try:
        movie = api.get_movie('550')
        if movie:
            print(f"(OK) Success!")
            print(f"  - Title: {movie.get('title', 'N/A')}")
            print(f"  - Release Date: {movie.get('release_date', 'N/A')}")
            print(f"  - Rating: {movie.get('vote_average', 'N/A')}/10")
            print(f"  - Overview: {movie.get('overview', 'N/A')[:100]}...")
        else:
            print("(X) Failed - No movie data returned")
    except Exception as e:
        print(f"(X) Error: {e}")

    # Test 3: Search for a movie
    print("\n[Test 3] Searching for 'The Matrix'...")
    try:
        results = api.search_movie('The Matrix')
        if results and 'results' in results:
            print(f"(OK) Success! Found {len(results['results'])} results")
            if results['results']:
                first = results['results'][0]
                print(f"  - Top result: {first.get('title', 'N/A')} ({first.get('release_date', 'N/A')[:4]})")
        else:
            print("(X) Failed - No results returned")
    except Exception as e:
        print(f"(X) Error: {e}")

    # Test 4: Get popular TV shows
    print("\n[Test 4] Getting popular TV shows...")
    try:
        shows = api.get_popular_tv()
        if shows and 'results' in shows:
            print(f"(OK) Success! Found {len(shows['results'])} popular TV shows")
            if shows['results']:
                first = shows['results'][0]
                print(f"  - First show: {first.get('name', 'N/A')} ({first.get('first_air_date', 'N/A')[:4]})")
        else:
            print("(X) Failed - No results returned")
    except Exception as e:
        print(f"(X) Error: {e}")

    print("\n" + "="*80)


def test_tvdb_api():
    """Test TVDb API with simple calls"""
    print("\n" + "="*80)
    print("TESTING TVDb API")
    print("="*80)

    api = TVDbAPI()
    print(f"(OK) TVDbAPI initialized")
    print(f"  - API Key: {api.api_key[:8]}...")
    print(f"  - Authenticated: {bool(api.token)}")

    if not api.token:
        print("\n(X) Authentication failed - cannot proceed with tests")
        print("="*80)
        return

    # Test 1: Get series (Breaking Bad - TVDb ID: 81189)
    print("\n[Test 1] Getting series details (Breaking Bad - ID: 81189)...")
    try:
        series = api.get_series('81189')
        if series:
            print(f"(OK) Success!")
            print(f"  - Name: {series.get('name', 'N/A')}")
            print(f"  - First Aired: {series.get('firstAired', 'N/A')}")
            print(f"  - Status: {series.get('status', {}).get('name', 'N/A')}")
            print(f"  - Overview: {series.get('overview', 'N/A')[:100]}...")
        else:
            print("(X) Failed - No series data returned")
    except Exception as e:
        print(f"(X) Error: {e}")

    # Test 2: Search for a series
    print("\n[Test 2] Searching for 'Game of Thrones'...")
    try:
        results = api.search_series('Game of Thrones')
        if results:
            print(f"(OK) Success! Found {len(results)} results")
            if results:
                first = results[0]
                print(f"  - Top result: {first.get('name', 'N/A')} ({first.get('first_air_time', 'N/A')[:4] if first.get('first_air_time') else 'N/A'})")
        else:
            print("(X) Failed - No results returned")
    except Exception as e:
        print(f"(X) Error: {e}")

    print("\n" + "="*80)


def test_fanart_api():
    """Test Fanart API with simple calls"""
    print("\n" + "="*80)
    print("TESTING Fanart.tv API")
    print("="*80)

    api = FanartAPI()
    print(f"(OK) FanartAPI initialized")
    print(f"  - API Key: {api.api_key[:8]}...")
    print(f"  - VIP Enabled: {bool(api.client_key)}")

    # Test 1: Get TV artwork (Breaking Bad - TVDb ID: 81189)
    print("\n[Test 1] Getting TV artwork (Breaking Bad - TVDb ID: 81189)...")
    try:
        artwork = api.get_tv_artwork('81189')
        if artwork:
            print(f"(OK) Success! Found artwork types:")
            for art_type, items in artwork.items():
                if items:
                    print(f"  - {art_type}: {len(items)} items")
        else:
            print("(X) Failed - No artwork returned")
    except Exception as e:
        print(f"(X) Error: {e}")

    # Test 2: Get specific TV poster
    print("\n[Test 2] Getting TV poster (Breaking Bad)...")
    try:
        poster = api.get_tv_poster('81189')
        if poster:
            print(f"(OK) Success!")
            print(f"  - Poster URL: {poster[:60]}...")
        else:
            print("(X) Failed - No poster returned")
    except Exception as e:
        print(f"(X) Error: {e}")

    # Test 3: Get movie artwork (Fight Club - TMDb ID: 550)
    print("\n[Test 3] Getting movie artwork (Fight Club - TMDb ID: 550)...")
    try:
        artwork = api.get_movie_artwork('550')
        if artwork:
            print(f"(OK) Success! Found artwork types:")
            for art_type, items in artwork.items():
                if items:
                    print(f"  - {art_type}: {len(items)} items")
        else:
            print("(X) Failed - No artwork returned")
    except Exception as e:
        print(f"(X) Error: {e}")

    # Test 4: Get specific movie poster
    print("\n[Test 4] Getting movie poster (Fight Club)...")
    try:
        poster = api.get_movie_poster('550')
        if poster:
            print(f"(OK) Success!")
            print(f"  - Poster URL: {poster[:60]}...")
        else:
            print("(X) Failed - No poster returned")
    except Exception as e:
        print(f"(X) Error: {e}")

    print("\n" + "="*80)


def main():
    """Run all API tests"""
    print("\n" + "="*80)
    print("NEW API CLASSES - TEST SUITE")
    print("="*80)
    print("\nThis test suite will verify the new API classes:")
    print("  • TMDbAPI  - The Movie Database API")
    print("  • TVDbAPI  - TheTVDB API")
    print("  • FanartAPI - Fanart.tv API")
    print("")

    # Run tests
    test_tmdb_api()
    test_tvdb_api()
    test_fanart_api()

    # Summary
    print("\n" + "="*80)
    print("TEST SUITE COMPLETED")
    print("="*80)
    print("\nNOTE: Some tests may fail if:")
    print("  • API keys are not properly configured")
    print("  • Network connection is unavailable")
    print("  • API services are experiencing issues")
    print("  • Rate limits are exceeded")
    print("")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n(X) Tests interrupted by user")
    except Exception as e:
        print(f"\n\n(X) Unexpected error: {e}")
        import traceback
        traceback.print_exc()
