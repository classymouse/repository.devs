# -*- coding: utf-8 -*-

'''
 ***********************************************************
 * The Crew Add-on - Scraper Testing Module
 *
 * @file scraper_test.py
 * @package script.module.thecrew
 *
 * @copyright (c) 2026, The Crew
 * @license GNU General Public License, version 3 (GPL-3.0)
 *
 * Provides connectivity testing for scrapers to help diagnose
 * geo-blocking and connection issues.
 ***********************************************************
'''

import time
import json
from datetime import datetime
from urllib.parse import urlparse
import sqlite3 as database

from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules.crewruntime import c


class ScraperTester:
    """Test scraper connectivity and cache results."""

    def __init__(self):
        self.cache_file = control.cacheFile
        self.cache_table = 'scraper_status'
        self._ensure_cache_table()

    def _ensure_cache_table(self):
        """Ensure the scraper status cache table exists."""
        try:
            control.makeFile(control.dataPath)
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('''
                CREATE TABLE IF NOT EXISTS scraper_status (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scraper_name TEXT UNIQUE,
                    category TEXT,
                    module_name TEXT,
                    accessible INTEGER,
                    working INTEGER,
                    disabled INTEGER,
                    defunct INTEGER,
                    pack_capable INTEGER,
                    response_time REAL,
                    error TEXT,
                    last_tested INTEGER
                )
            ''')
            dbcon.commit()
            dbcur.close()
            dbcon.close()
        except Exception as e:
            c.log(f'[ScraperTest] Error creating cache table: {e}', 1)

    def load_status(self):
        """Load cached scraper status from database."""
        try:
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('SELECT * FROM scraper_status')
            rows = dbcur.fetchall()
            dbcur.close()
            dbcon.close()

            if not rows:
                return None

            # Organize by category
            result = {
                'direct': [],
                'torrent': [],
                'usenet': [],
                'summary': {}
            }

            total = 0
            working = 0
            accessible = 0
            blocked = 0
            disabled = 0
            last_updated = 0

            for row in rows:
                scraper = {
                    'name': row[1],
                    'category': row[2],
                    'module': row[3],
                    'accessible': bool(row[4]),
                    'working': bool(row[5]),
                    'disabled': bool(row[6]),
                    'defunct': bool(row[7]),
                    'pack_capable': bool(row[8]),
                    'response_time': row[9],
                    'error': row[10]
                }

                # Track timestamp
                if row[11] and row[11] > last_updated:
                    last_updated = row[11]

                # Categorize
                category = row[2] or 'direct'
                if category.startswith('torrent') or category == 'en_tor':
                    result['torrent'].append(scraper)
                elif category.startswith('usenet'):
                    result['usenet'].append(scraper)
                else:
                    result['direct'].append(scraper)

                # Count for summary
                total += 1
                if scraper['disabled']:
                    disabled += 1
                elif scraper['working']:
                    working += 1
                elif scraper['accessible']:
                    accessible += 1
                else:
                    blocked += 1

            # Build summary
            result['summary'] = {
                'total': total,
                'working': working,
                'accessible': accessible,
                'blocked': blocked,
                'disabled': disabled,
                'last_updated': datetime.fromtimestamp(last_updated).isoformat() if last_updated else None
            }

            return result

        except Exception as e:
            c.log(f'[ScraperTest] Error loading status: {e}', 1)
            return None

    def is_cache_valid(self, max_age_hours=24):
        """Check if cached data is still valid."""
        try:
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('SELECT MAX(last_tested) FROM scraper_status')
            result = dbcur.fetchone()
            dbcur.close()
            dbcon.close()

            if not result or not result[0]:
                return False

            age_seconds = time.time() - result[0]
            max_age_seconds = max_age_hours * 3600
            return age_seconds < max_age_seconds

        except Exception as e:
            c.log(f'[ScraperTest] Error checking cache validity: {e}', 1)
            return False

    def test_all_scrapers(self, test_type='connectivity', progress_callback=None):
        """
        Test all scrapers for connectivity.

        :param test_type: Type of test - 'connectivity' checks if domain is reachable
        :param progress_callback: Callback function(current, total, name) for progress
        :return: Dictionary with test results organized by category
        """
        c.log('[ScraperTest] Starting scraper connectivity tests')

        # Check scraper pack settings
        cocoscrapers_enabled = c.get_setting('cocoscrapers.enabled') == 'true'
        gearsscrapers_enabled = c.get_setting('gearsscrapers.enabled') == 'true'
        viperscrapers_enabled = c.get_setting('viperscrapers.enabled') == 'true'

        c.log(f'[ScraperTest] Scraper pack settings: coco={cocoscrapers_enabled}, gears={gearsscrapers_enabled}, viper={viperscrapers_enabled}')

        # Load all scrapers
        try:
            from resources.lib.sources import sources as load_sources
            source_list = load_sources()
        except Exception as e:
            c.log(f'[ScraperTest] Error loading scrapers: {e}', 1)
            return None

        if not source_list:
            c.log('[ScraperTest] No scrapers found', 1)
            return None

        c.log(f'[ScraperTest] Testing {len(source_list)} scrapers')

        # Clear old cache
        try:
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('DELETE FROM scraper_status')
            dbcon.commit()
            dbcur.close()
            dbcon.close()
        except Exception as e:
            c.log(f'[ScraperTest] Error clearing cache: {e}', 1)

        current_time = int(time.time())
        total = len(source_list)
        current = 0

        results = []

        for module_name, scraper_obj in source_list:
            current += 1

            # Get scraper info
            try:
                name = getattr(scraper_obj, 'name', module_name.split('.')[-1])

                # Determine category
                if 'torrent' in module_name.lower() or 'en_tor' in module_name.lower():
                    category = 'torrent'
                elif 'usenet' in module_name.lower():
                    category = 'usenet'
                else:
                    category = 'direct'

                # Check if scraper pack is disabled in settings
                pack_disabled = False
                if 'cocoscrapers' in module_name.lower() and not cocoscrapers_enabled:
                    pack_disabled = True
                elif 'gearsscrapers' in module_name.lower() and not gearsscrapers_enabled:
                    pack_disabled = True
                elif 'viperscrapers' in module_name.lower() and not viperscrapers_enabled:
                    pack_disabled = True

                # Check if disabled or defunct at scraper level
                disabled = pack_disabled or getattr(scraper_obj, 'disabled', False)
                defunct = getattr(scraper_obj, 'defunct', False)
                pack_capable = getattr(scraper_obj, 'pack_capable', False)

                # Progress callback
                if progress_callback:
                    status_label = "DISABLED" if disabled else ("DEFUNCT" if defunct else name)
                    if not progress_callback(current, total, status_label):
                        c.log('[ScraperTest] Test cancelled by user')
                        break

                # Test connectivity (skip if disabled or defunct)
                accessible = False
                working = False
                response_time = None
                error = None

                if disabled:
                    error = 'DISABLED'
                elif defunct:
                    error = 'Defunct'
                else:
                    accessible, working, response_time, error = self._test_scraper_connectivity(
                        scraper_obj, name
                    )

                # Store result
                result = {
                    'name': name,
                    'category': category,
                    'module': module_name,
                    'accessible': accessible,
                    'working': working,
                    'disabled': disabled,
                    'defunct': defunct,
                    'pack_capable': pack_capable,
                    'response_time': response_time,
                    'error': error
                }
                results.append(result)

                # Cache to database
                try:
                    dbcon = database.connect(self.cache_file)
                    dbcur = dbcon.cursor()
                    dbcur.execute('''
                        INSERT OR REPLACE INTO scraper_status
                        (scraper_name, category, module_name, accessible, working,
                         disabled, defunct, pack_capable, response_time, error, last_tested)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        name, category, module_name,
                        1 if accessible else 0,
                        1 if working else 0,
                        1 if disabled else 0,
                        1 if defunct else 0,
                        1 if pack_capable else 0,
                        response_time,
                        error,
                        current_time
                    ))
                    dbcon.commit()
                    dbcur.close()
                    dbcon.close()
                except Exception as e:
                    c.log(f'[ScraperTest] Error caching result for {name}: {e}', 1)

            except Exception as e:
                c.log(f'[ScraperTest] Error testing {module_name}: {e}', 1)
                continue

        # Organize results by category
        organized = {
            'direct': [],
            'torrent': [],
            'usenet': [],
            'summary': {}
        }

        total_count = 0
        working_count = 0
        accessible_count = 0
        blocked_count = 0
        disabled_count = 0

        for result in results:
            cat = result['category']
            if cat == 'torrent':
                organized['torrent'].append(result)
            elif cat == 'usenet':
                organized['usenet'].append(result)
            else:
                organized['direct'].append(result)

            # Count for summary
            total_count += 1
            if result['disabled']:
                disabled_count += 1
            elif result['working']:
                working_count += 1
            elif result['accessible']:
                accessible_count += 1
            else:
                blocked_count += 1

        organized['summary'] = {
            'total': total_count,
            'working': working_count,
            'accessible': accessible_count,
            'blocked': blocked_count,
            'disabled': disabled_count,
            'last_updated': datetime.fromtimestamp(current_time).isoformat()
        }

        c.log(f'[ScraperTest] Testing complete: {working_count} working, {accessible_count} accessible, {blocked_count} blocked, {disabled_count} disabled')

        return organized

    def _test_scraper_connectivity(self, scraper_obj, name):
        """
        Test if a scraper's domain is accessible.

        :return: (accessible, working, response_time, error)
        """
        try:
            # Get domain from scraper
            domains = getattr(scraper_obj, 'domains', [])
            base_link = getattr(scraper_obj, 'base_link', None)
            search_link = getattr(scraper_obj, 'search_link', None)

            # Extract base domain
            test_url = None
            if domains and len(domains) > 0:
                test_url = f"https://{domains[0]}"
            elif base_link:
                test_url = base_link
            else:
                return False, False, None, 'No domain configured'

            # If scraper has a search endpoint, use that instead of just the base
            # (Some sites block base domain but API endpoints work fine - e.g., apibay.org)
            if search_link:
                try:
                    # Build a test search URL
                    from urllib.parse import urljoin, quote_plus
                    if '%s' in search_link:
                        # Replace %s with a simple test query
                        test_search = search_link % quote_plus('test')
                    else:
                        test_search = search_link
                    test_url = urljoin(test_url, test_search)
                    c.log(f'[ScraperTest] Using search endpoint for {name}: {test_url}')
                except Exception as e:
                    c.log(f'[ScraperTest] Could not build search URL, using base: {e}')

            # Test HTTP connectivity
            c.log(f'[ScraperTest] Testing {name}: {test_url}')
            start_time = time.time()
            try:
                # Use longer timeout (20 seconds) for better reliability
                result = client.request(test_url, timeout=20, output='response')
                response_time = time.time() - start_time

                if result:
                    status_code = result.status_code if hasattr(result, 'status_code') else 200
                    c.log(f'[ScraperTest] {name} returned HTTP {status_code} ({response_time:.2f}s)')

                    if status_code < 400:
                        # Site is accessible and working
                        return True, True, response_time, None
                    elif status_code in [403, 451]:
                        # Site exists but geo-blocked - mark as accessible
                        return True, False, response_time, f'HTTP {status_code} - Possibly geo-blocked'
                    elif status_code in [503, 429]:
                        # Site exists but rate limited - mark as accessible
                        return True, False, response_time, f'HTTP {status_code} - Rate limited'
                    else:
                        return True, False, response_time, f'HTTP {status_code}'
                else:
                    c.log(f'[ScraperTest] {name} returned no response')
                    return False, False, None, 'No response'

            except Exception as req_error:
                error_msg = str(req_error)
                c.log(f'[ScraperTest] {name} request error: {error_msg[:100]}')

                # Categorize errors - Be more lenient with CloudFlare/SSL issues
                if 'timeout' in error_msg.lower():
                    return False, False, None, 'Connection timeout'
                elif 'cloudflare' in error_msg.lower() or 'cf-ray' in error_msg.lower():
                    # CloudFlare challenge - site is accessible, just protected
                    return True, False, None, 'CloudFlare protected'
                elif 'ssl' in error_msg.lower() or 'certificate' in error_msg.lower():
                    # SSL errors often mean site is accessible, just cert issues
                    return True, False, None, 'SSL/Certificate issue'
                elif 'blocked' in error_msg.lower() or '403' in error_msg:
                    # Explicitly blocked but site exists
                    return True, False, None, 'Access blocked'
                elif 'connection refused' in error_msg.lower():
                    return False, False, None, 'Connection refused'
                elif 'name or service not known' in error_msg.lower() or 'getaddrinfo failed' in error_msg.lower():
                    return False, False, None, 'DNS resolution failed'
                else:
                    # Unknown error - mark as inaccessible
                    return False, False, None, f'Error: {error_msg[:50]}'

        except Exception as e:
            c.log(f'[ScraperTest] Error testing {name}: {e}', 1)
            return False, False, None, f'Test error: {str(e)[:50]}'

    def clear_cache(self):
        """Clear all cached scraper test results."""
        try:
            dbcon = database.connect(self.cache_file)
            dbcur = dbcon.cursor()
            dbcur.execute('DELETE FROM scraper_status')
            dbcon.commit()
            dbcur.close()
            dbcon.close()
            c.log('[ScraperTest] Cache cleared')
            return True
        except Exception as e:
            c.log(f'[ScraperTest] Error clearing cache: {e}', 1)
            return False
